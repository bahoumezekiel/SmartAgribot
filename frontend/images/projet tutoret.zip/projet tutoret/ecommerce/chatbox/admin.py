from django.contrib import admin
from .models import FAQ

admin.site.register(FAQ)
